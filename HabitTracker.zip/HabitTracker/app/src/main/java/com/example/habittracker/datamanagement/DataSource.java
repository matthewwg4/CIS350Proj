package com.example.habittracker.datamanagement;

public abstract class DataSource {
    //all fake databases should extend this
    //eventually replace with real database stuff
}
