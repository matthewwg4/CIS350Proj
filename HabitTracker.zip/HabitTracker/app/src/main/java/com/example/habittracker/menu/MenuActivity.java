package com.example.habittracker.menu;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.example.habittracker.datamanagement.FakeResourceDatabase;
import com.example.habittracker.datamanagement.FakeSurveyDatabase;
import com.example.habittracker.datamanagement.Resource;
import com.example.habittracker.datamanagement.Survey;
import com.example.habittracker.login.R;
import com.example.habittracker.resources.ResourcesActivity;
import com.example.habittracker.surveys.SurveyActivity;

import java.util.TreeMap;

public class MenuActivity extends AppCompatActivity {

    FakeSurveyDatabase f = FakeSurveyDatabase.getInstance();
    private TreeMap<String, Survey> surveys = f.getSurInfo();

    private String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }
    //add onclick methods for habit and viz buttons during integration

    public void gotoResources(View v) {
        String msg = getIntent().getStringExtra("user");
        Intent i = new Intent(getApplicationContext(), ResourcesActivity.class);
        i.putExtra("user", msg);

        startActivity(i);
    }

    public void gotoSurveys(View v) {
        boolean surveysToDo = false;
        String msg = getIntent().getStringExtra("user");

        for(Survey s: surveys.values()) {
            if(!s.responses.containsKey(msg)) {
                surveysToDo = true;
            }
        }

        if(!surveysToDo) {
            Toast.makeText(getApplicationContext(), "There are currently no unfinished surveys for you. Please check back later.", Toast.LENGTH_LONG).show();
        } else {
            Intent i = new Intent(getApplicationContext(), SurveyActivity.class);
            i.putExtra("user", msg);

            startActivity(i);
        }


    }
}
